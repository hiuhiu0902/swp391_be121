package fu.se.myplatform.service;

import fu.se.myplatform.dto.FagerstromTestRequest;
import fu.se.myplatform.entity.Account;
import fu.se.myplatform.entity.Assessment;
import fu.se.myplatform.entity.Member;
import fu.se.myplatform.enums.DependencyLevel;
import fu.se.myplatform.repository.AssessmentRepository;
import fu.se.myplatform.repository.MemberRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;

@Service
public class FagerstromService {
    @Autowired AssessmentRepository assessmentRepository;
    @Autowired AuthenticationService authenticationService;
    @Autowired QuitPlanService  quitPlanService;
    @Autowired
    MemberRepository memberRepository;


    public Assessment performAndSaveAssessment(FagerstromTestRequest testRequest) {
        Account account = authenticationService.getCurrentAccount();
        Member member = memberRepository.findByUser(account);
        if (testRequest == null) {
            throw new IllegalArgumentException("Fagerstrom test request cannot be null");
        }
        Assessment assessment = assessmentRepository.findByAccount(account);
        if(assessment == null) {
            int score = calculateFagerstromScore(testRequest);
            DependencyLevel level = determineDependencyLevel(score);
            Account currentUser = authenticationService.getCurrentAccount();
            Assessment newAssessment = new Assessment();
            newAssessment.setScore(score);
            newAssessment.setDependencyLevel(level);
            newAssessment.setAccount(currentUser);
            newAssessment.setCreatedAt(LocalDateTime.now());
            assessmentRepository.save(newAssessment);
        }else if(assessment != null){
            int score = calculateFagerstromScore(testRequest);
            DependencyLevel level = determineDependencyLevel(score);

            assessment.setScore(score);
            assessment.setDependencyLevel(level);
            assessment.setCreatedAt(LocalDateTime.now());
            assessmentRepository.save(assessment);
        }
        return null;
    }

    private int calculateFagerstromScore(FagerstromTestRequest test) {
        return test.getAnswer1() + test.getAnswer2() + test.getAnswer3() +
                test.getAnswer4() + test.getAnswer5() + test.getAnswer6();
    }

    private DependencyLevel determineDependencyLevel(int score) {
        if (score <= 8) return DependencyLevel.LOW;
        if (score <= 15) return DependencyLevel.MEDIUM;
        return DependencyLevel.HIGH;
    }
}
