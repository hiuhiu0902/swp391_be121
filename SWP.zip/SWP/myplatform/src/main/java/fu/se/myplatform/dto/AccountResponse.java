package fu.se.myplatform.dto;

import fu.se.myplatform.enums.Gender;
import fu.se.myplatform.enums.Role;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import lombok.Data;

import java.time.LocalDate;
import java.time.LocalDateTime;

@Data
public class AccountResponse {

    public String userName;

    public String password;

    public String fullName;

    public String email;

    public String phoneNumber;

    public Role role;

    public Gender gender;

    public String token;

    public String status;

    public LocalDateTime createdAt;
    public Long userId;

    // Thông tin riêng cho từng loại tài khoản, gom chung vào DTO này
    public Boolean isVip;
    public LocalDate vipStartDate;
    public LocalDate vipExpiryDate;
    public String memberStatus;
    public String staffPosition;
    public String staffStatus;
    public String coachAddress;
    public String coachStatus;


    // Thêm memberId và coachId
    public Long memberId;  // Member ID
    public Long coachId;   // Coach ID

}
