package fu.se.myplatform.enums;

public enum Gender {
    MALE,
    FEMALE
}
