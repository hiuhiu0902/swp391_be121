package fu.se.myplatform.dto;

import lombok.Data;

@Data
public class ForgotPasswordRequest {
    public String email;
}
