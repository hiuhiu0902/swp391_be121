package fu.se.myplatform.api;

import fu.se.myplatform.entity.Member;
import fu.se.myplatform.repository.MemberRepository;
import fu.se.myplatform.service.MemberService;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/member")
@SecurityRequirement(
        name = "api"
)
public class MemberAPI {
    @Autowired
    MemberRepository memberRepository;
    @Autowired
    MemberService memberService;
    @GetMapping("/{memberId}")
    public ResponseEntity getMembeProfile(@PathVariable Long memberId) {
        Member member = memberService.getMemberProfile(memberId);
        return ResponseEntity.ok().body(member);
    }
//    public ResponseEntity updateMemberImage(@RequestParam('fi'))
}
