package fu.se.myplatform.dto;

import lombok.Data;

@Data
public class SmokingRecordRequest {
    private int cigarettesSmoked;
}
