package fu.se.myplatform.service;

import fu.se.myplatform.entity.Member;
import fu.se.myplatform.exception.exception.AuthenticationException;
import fu.se.myplatform.repository.MemberRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;

@Service
public class MemberService {
    @Autowired
    private MemberRepository memberRepository;
    public Member updateMemberImage(Long memberId, MultipartFile file) throws IOException {
        Member member = memberRepository.findById(memberId)
                .orElseThrow(() -> new AuthenticationException("Member not found"));
        byte[] imageBytes = file.getBytes();
        member.setProfileImage(imageBytes);
        return memberRepository.save(member);
    }
    public Member getMemberProfile(Long memberId) {
        return memberRepository.findById(memberId)
                .orElseThrow(() -> new AuthenticationException("Member not found"));
    }
}
